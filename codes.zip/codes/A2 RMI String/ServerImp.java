import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class ServerImp extends UnicastRemoteObject implements ServerIntf{

    public ServerImp() throws RemoteException
    {
        super();
    }

    public int length(String str) throws RemoteException
    {
        return str.length();
    }

    public String reverse(String str) throws RemoteException
    {
        return new StringBuilder(str).reverse().toString();
    }

    public String Concate(String s1, String s2) throws RemoteException
    {
        return s1+s2;
    }

    public boolean isPalindrome(String str) throws RemoteException
    {
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }

    public boolean isEqual(String s1, String s2) throws RemoteException
    {
        return s1.equals(s2);
    }
    
    
}
