import java.rmi.*;

public class Server {

    public static void main(String args[])
    {
        try {

            ServerImp serverImp = new ServerImp();
            Naming.rebind("Server", serverImp);

            System.out.println("server Started");
            
        } catch (Exception e) {
           System.out.println("Exception occured"+e.getMessage());
        }
    }
    
}
