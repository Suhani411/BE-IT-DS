import java.rmi.*;
import java.util.Scanner;

public class Client {

    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        try {

            String serverURL= "rmi://localhost/Server";
            ServerIntf serverIntf = (ServerIntf) Naming.lookup(serverURL);

            System.out.println("Enter first Word:");
            String s1 = sc.next();

            System.out.println("Enter Second Word:");
            String s2 = sc.next();

            System.out.println("First world:"+s1);
            System.out.println("Second world:"+s2);

            System.out.println("--------Result------");

            System.out.println("Length of first Word is:"+serverIntf.length(s1));
            System.out.println("Reverse String:"+serverIntf.reverse(s1));
            System.out.println("COncatenation of String:"+serverIntf.Concate(s1, s2));
            System.out.println("Palindrome:"+serverIntf.isPalindrome(s1));
            System.out.println("Equal to:"+serverIntf.isEqual(s1, s2));
            
        } catch (Exception e) {
            System.out.println("Exception Occured"+e.getMessage());
        }
    }
    
}
