import java.rmi.*;
public interface ServerIntf extends Remote{

    public int length(String str) throws RemoteException;
    public String reverse(String str) throws RemoteException;
    public String Concate(String s1, String s2) throws RemoteException;
    public boolean isPalindrome(String str) throws RemoteException;
    public boolean isEqual(String s1, String s2) throws RemoteException;
    
}
