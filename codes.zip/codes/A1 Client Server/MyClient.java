import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MyClient{

    public static void main(String args[]) throws Exception
    {
        Socket socket =new Socket("127.0.0.1",5555);

        System.out.println("Connected to server");

        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);

        BufferedReader keyboardReader = new BufferedReader(new InputStreamReader(System.in));

        while (true) {

            System.out.println("Client");

            String clientmsg= keyboardReader.readLine();
            writer.print(clientmsg);

            if(clientmsg.equalsIgnoreCase("bye"))
            {
                System.out.println("Client Existing...");
                break;
            }

            String servermsg = reader.readLine();
            if(servermsg==null || servermsg.equalsIgnoreCase("bye"))
            {
                System.out.println("Server Disconnected");
                break;
            }

            System.out.println("Server:"+servermsg);
            
        }
        socket.close();
    }
}