import java.io.*;
import java.net.*;

public class MyServer{

    public static void main(String args[]) throws Exception
    {
        ServerSocket serverSocket = new ServerSocket(5555);
        System.out.println("Server Started, waiting for client..");
        
        Socket socket = serverSocket.accept();
        System.out.println("Client connected:"+socket);

        BufferedReader reader= new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);

        BufferedReader keyboardReader = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            String clientmsg = reader.readLine();
            if(clientmsg==null || clientmsg.equalsIgnoreCase("bye"))
            {
                System.out.println("Client disconnected");
                break;
            }
            System.out.println("Client:" + clientmsg);

            System.out.println("Server:");

            String servermsg = keyboardReader.readLine();
            writer.print(servermsg);

            if(servermsg.equalsIgnoreCase("bye"))
            {
                System.out.println("server exiting");
                break;
            }
        }

        socket.close();
        serverSocket.close();

   

    }

}
