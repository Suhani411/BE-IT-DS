import java.rmi.*;
import java.rmi.server.*;

public class ServerImp extends UnicastRemoteObject implements ServerIntf {

    public ServerImp() throws RemoteException
    {
        super();
    }

    public double Addition(double num1, double num2) throws RemoteException
    {
        return num1+num2;
    }

    public double Substraction(double num1, double num2) throws RemoteException
    {
        return num1-num2;
    }     

    public double Multiplication(double num1, double num2) throws RemoteException
    {
        return num1*num2;
    }   

    public double Division(double num1, double num2) throws RemoteException
    {
        if ((num2!=0)) 
        {
            return num1/num2;
        }
        else
        {
            System.out.println("Can not divide by zero");
            
        }
        return num1/num2;
       
    }     
    
}


    

